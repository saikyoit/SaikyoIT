package com.example.videoenhancer

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.util.Size
import androidx.media3.effect.GlEffect
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram

/** Индексы параметров. Первые три 0..1, остальные -1..1. */
object P {
    const val SHARPEN = 0
    const val STRUCTURE = 1
    const val CLARITY = 2
    const val EXPOSURE = 3
    const val BRIGHTNESS = 4
    const val CONTRAST = 5
    const val SATURATION = 6
    const val VIBRANCE = 7
    const val TEMPERATURE = 8
    const val TINT = 9
    const val COUNT = 10
}

class EnhanceParams(val v: FloatArray = FloatArray(P.COUNT)) {
    fun copy() = EnhanceParams(v.copyOf())
    fun isIdentity() = v.all { it == 0f }
}

@UnstableApi
class EnhanceEffect(private val params: EnhanceParams) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean) =
        EnhanceShaderProgram(useHdr, params.copy())
}

@UnstableApi
class EnhanceShaderProgram(useHdr: Boolean, private val p: EnhanceParams) :
    BaseGlShaderProgram(useHdr, 1) {

    private val glProgram = GlProgram(VERTEX, FRAGMENT)

    init {
        glProgram.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
        )
        glProgram.setFloatsUniform("uTransformationMatrix", GlUtil.create4x4IdentityMatrix())
        val v = p.v
        glProgram.setFloatsUniform(
            "uA", floatArrayOf(v[P.SHARPEN], v[P.STRUCTURE], v[P.CLARITY], v[P.EXPOSURE])
        )
        glProgram.setFloatsUniform(
            "uB", floatArrayOf(v[P.BRIGHTNESS], v[P.CONTRAST], v[P.SATURATION], v[P.VIBRANCE])
        )
        glProgram.setFloatsUniform("uC", floatArrayOf(v[P.TEMPERATURE], v[P.TINT]))
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        glProgram.setFloatsUniform("uTexel", floatArrayOf(1f / inputWidth, 1f / inputHeight))
        return Size(inputWidth, inputHeight)
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            glProgram.use()
            glProgram.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            glProgram.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            glProgram.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    companion object {
        private const val VERTEX = """
attribute vec4 aFramePosition;
uniform mat4 uTransformationMatrix;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = uTransformationMatrix * aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""

        private const val FRAGMENT = """
precision highp float;
uniform sampler2D uTexSampler;
uniform vec2 uTexel;
uniform vec4 uA; // sharpen, structure, clarity, exposure
uniform vec4 uB; // brightness, contrast, saturation, vibrance
uniform vec2 uC; // temperature, tint
varying vec2 vTexSamplingCoord;

vec3 tex(vec2 o) {
  return texture2D(uTexSampler, vTexSamplingCoord + o * uTexel).rgb;
}

vec3 ring(float r) {
  float d = r * 0.7071;
  return (tex(vec2(r, 0.0)) + tex(vec2(-r, 0.0)) + tex(vec2(0.0, r)) + tex(vec2(0.0, -r))
        + tex(vec2(d, d)) + tex(vec2(-d, d)) + tex(vec2(d, -d)) + tex(vec2(-d, -d))) * 0.125;
}

void main() {
  vec3 c = tex(vec2(0.0));
  vec3 base = c;
  const vec3 luma = vec3(0.2126, 0.7152, 0.0722);

  // Детализация: тонкая (Sharpen), средняя (Structure), крупная (Clarity)
  if (uA.x > 0.0) {
    vec3 blur1 = (ring(1.0) * 0.8 + c * 0.2);
    c += (base - blur1) * (uA.x * 2.2);
  }
  if (uA.y > 0.0) {
    vec3 blur3 = ring(3.0);
    c += (base - blur3) * (uA.y * 1.4);
  }
  if (uA.z > 0.0) {
    vec3 blur9 = (ring(9.0) + ring(5.0)) * 0.5;
    float l = dot(base, luma);
    float mid = 1.0 - abs(2.0 * l - 1.0);
    c += (base - blur9) * (uA.z * 1.0 * (0.4 + 0.6 * mid));
  }

  // Экспозиция и яркость
  c *= exp2(uA.w * 1.5);
  c += uB.x * 0.25;

  // Контраст
  c = (c - 0.5) * (1.0 + uB.y * 0.9) + 0.5;

  // Температура и оттенок
  c.r += uC.x * 0.12;
  c.b -= uC.x * 0.12;
  c.g -= uC.y * 0.10;
  c.r += uC.y * 0.04;
  c.b += uC.y * 0.04;

  // Насыщенность и сочность
  float l2 = dot(c, luma);
  float sat = max(c.r, max(c.g, c.b)) - min(c.r, min(c.g, c.b));
  float k = (1.0 + uB.z) * (1.0 + uB.w * (1.0 - clamp(sat, 0.0, 1.0)));
  c = mix(vec3(l2), c, k);

  gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
"""
    }
}
