package com.example.videoenhancer

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.widget.AdapterView
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.ui.PlayerView
import java.io.File

@UnstableApi
class MainActivity : ComponentActivity() {

    private data class Spec(val index: Int, val label: String, val bipolar: Boolean)

    private val specs = listOf(
        Spec(P.SHARPEN, "Резкость (Sharpen)", false),
        Spec(P.STRUCTURE, "Структура (Structure)", false),
        Spec(P.CLARITY, "Чёткость (Clarity)", false),
        Spec(P.EXPOSURE, "Экспозиция", true),
        Spec(P.BRIGHTNESS, "Яркость", true),
        Spec(P.CONTRAST, "Контраст", true),
        Spec(P.SATURATION, "Насыщенность", true),
        Spec(P.VIBRANCE, "Сочность", true),
        Spec(P.TEMPERATURE, "Температура", true),
        Spec(P.TINT, "Оттенок", true),
    )

    private val params = EnhanceParams()
    private var videoUri: Uri? = null
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var exportBtn: Button
    private val bars = HashMap<Int, SeekBar>()
    private val labels = HashMap<Int, TextView>()
    private var resolutionIdx = 0
    private var transformer: Transformer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val applyRunnable = Runnable { applyPreview() }

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawableResource(android.R.color.transparent)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1B1F1E"))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        playerView = PlayerView(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1.2f)
        }
        root.addView(playerView)

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1.6f)
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(16))
        }
        scroll.addView(panel)
        root.addView(scroll)

        // Кнопки
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(button("Выбрать видео") {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
        })
        row1.addView(button("Авто") { runAuto() })
        row1.addView(button("Сброс") { resetAll() })
        panel.addView(row1)

        val compare = button("Удерживать: оригинал") {}.apply {
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> player?.setVideoEffects(emptyList())
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> applyPreview()
                }
                true
            }
        }
        panel.addView(compare)

        // Ползунки
        for (s in specs) {
            if (s.index == P.EXPOSURE) panel.addView(header("Цветокоррекция"))
            if (s.index == P.SHARPEN) panel.addView(header("Качество"))
            panel.addView(slider(s))
        }

        // Разрешение
        panel.addView(header("Апскейл при экспорте"))
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Как в оригинале", "Увеличить до 1080p", "Увеличить до 1440p")
        )
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                resolutionIdx = pos
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        panel.addView(sp)

        exportBtn = button("Сохранить видео") { export() }
        panel.addView(exportBtn)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; visibility = View.GONE
        }
        panel.addView(progress)
        status = TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = 13f
            text = "Выберите видео"
        }
        panel.addView(status)

        setContentView(root)
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).also {
            it.setMargins(dp(2), dp(2), dp(2), dp(2))
        }
        setOnClickListener { onClick() }
    }.also {
        if (it.parent == null) it.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
    }

    private fun header(t: String) = TextView(this).apply {
        text = t; setTextColor(Color.parseColor("#9BD3C0")); textSize = 15f
        setPadding(0, dp(14), 0, dp(2))
    }

    private fun slider(s: Spec): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; text = "${s.label}: 0"
        }
        val bar = SeekBar(this).apply {
            max = if (s.bipolar) 200 else 100
            progress = if (s.bipolar) 100 else 0
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    val v = if (s.bipolar) (p - 100) / 100f else p / 100f
                    params.v[s.index] = v
                    label.text = "${s.label}: ${(v * 100).toInt()}"
                    if (fromUser) {
                        handler.removeCallbacks(applyRunnable)
                        handler.postDelayed(applyRunnable, 120)
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {
                    handler.removeCallbacks(applyRunnable); applyPreview()
                }
            })
        }
        bars[s.index] = bar
        labels[s.index] = label
        box.addView(label); box.addView(bar)
        return box
    }

    private fun setSliders(src: EnhanceParams) {
        for (s in specs) {
            val v = src.v[s.index]
            bars[s.index]?.progress = if (s.bipolar) ((v + 1f) * 100).toInt() else (v * 100).toInt()
            params.v[s.index] = v
        }
        applyPreview()
    }

    private fun resetAll() = setSliders(EnhanceParams())

    private fun runAuto() {
        val uri = videoUri ?: return toast("Сначала выберите видео")
        status.text = "Анализ кадров…"
        Thread {
            val result = AutoCorrect.analyze(applicationContext, uri)
            runOnUiThread { setSliders(result); status.text = "Автокоррекция применена. Подстройте вручную." }
        }.start()
    }

    private fun loadVideo(uri: Uri) {
        videoUri = uri
        player?.release()
        player = ExoPlayer.Builder(this).build().also {
            playerView.player = it
            it.setMediaItem(MediaItem.fromUri(uri))
            it.repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
            it.prepare()
            it.playWhenReady = true
        }
        applyPreview()
        status.text = "Видео загружено"
    }

    private fun applyPreview() {
        val pl = player ?: return
        pl.setVideoEffects(if (params.isIdentity()) emptyList() else listOf(EnhanceEffect(params.copy())))
    }

    private fun export() {
        val uri = videoUri ?: return toast("Сначала выберите видео")
        player?.pause()
        val outFile = File(cacheDir, "enhanced_${System.currentTimeMillis()}.mp4")
        val effects = mutableListOf<Effect>()
        when (resolutionIdx) {
            1 -> effects += Presentation.createForHeight(1080)
            2 -> effects += Presentation.createForHeight(1440)
        }
        if (!params.isIdentity()) effects += EnhanceEffect(params.copy())

        val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri))
            .setEffects(Effects(emptyList(), effects))
            .build()

        val encoder = DefaultEncoderFactory.Builder(this)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(20_000_000).build()
            ).build()

        val t = Transformer.Builder(this)
            .setEncoderFactory(encoder)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacksAndMessages(null)
                    status.text = "Сохранение в галерею…"
                    Thread {
                        val ok = saveToGallery(outFile)
                        runOnUiThread {
                            progress.visibility = View.GONE
                            exportBtn.isEnabled = true
                            status.text = if (ok) "Готово: Movies/VideoEnhancer" else "Ошибка сохранения"
                        }
                    }.start()
                }

                override fun onError(
                    composition: Composition, exportResult: ExportResult, exportException: ExportException
                ) {
                    handler.removeCallbacksAndMessages(null)
                    progress.visibility = View.GONE
                    exportBtn.isEnabled = true
                    status.text = "Ошибка экспорта: ${exportException.message}"
                }
            })
            .build()
        transformer = t
        exportBtn.isEnabled = false
        progress.progress = 0
        progress.visibility = View.VISIBLE
        status.text = "Экспорт…"
        t.start(edited, outFile.absolutePath)

        val holder = ProgressHolder()
        val poll = object : Runnable {
            override fun run() {
                val st = t.getProgress(holder)
                if (st != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    progress.progress = holder.progress
                    status.text = "Экспорт… ${holder.progress}%"
                }
                if (st != Transformer.PROGRESS_STATE_NO_TRANSFORMATION) handler.postDelayed(this, 500)
            }
        }
        handler.post(poll)
    }

    private fun saveToGallery(file: File): Boolean = try {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "enhanced_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoEnhancer")
        }
        val dst = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)!!
        contentResolver.openOutputStream(dst)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        file.delete()
        true
    } catch (e: Exception) {
        false
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        player?.release()
    }
}
